import SwiftUI
import AVKit
import Vision
import UniformTypeIdentifiers

@main
struct AimTrackApp: App {
    var body: some Scene {
        WindowGroup {
            AimTrackView()
                .preferredColorScheme(.dark)
        }
    }
}

struct TargetSample: Identifiable {
    let id = UUID()
    let time: Double
    let position: CGPoint
    let confidence: Float
}

@MainActor
final class AimTrackModel: ObservableObject {
    @Published var player: AVPlayer?
    @Published var samples: [TargetSample] = []
    @Published var currentTime: Double = 0
    @Published var progress: Double = 0
    @Published var status = "Import a gameplay video to analyze targets"
    @Published var scanning = false
    @Published var sensitivity = 0.65
    @Published var showTrack = true

    private var observer: Any?
    private var currentPlayer: AVPlayer?

    func importVideo(_ url: URL) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        let dst = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        do {
            try FileManager.default.copyItem(at: url, to: dst)
        } catch {
            status = "Cannot import video: \(error.localizedDescription)"
            return
        }
        if let token = observer, let player = currentPlayer { player.removeTimeObserver(token) }
        let p = AVPlayer(url: dst)
        player = p
        currentPlayer = p
        samples = []
        currentTime = 0
        observer = p.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in self?.currentTime = time.seconds.isFinite ? time.seconds : 0 }
        }
        scanning = true
        status = "Scanning video…"
        progress = 0
        let gain = sensitivity
        Task.detached(priority: .userInitiated) { [weak self] in
            let result = await Self.analyze(url: dst, gain: gain) { p in
                Task { @MainActor [weak self] in self?.progress = p }
            }
            await MainActor.run { [weak self] in
                guard let self = self else { return }
                self.samples = result
                self.scanning = false
                self.progress = 1
                self.status = "Analysis complete • \(result.count) tracked frames"
            }
        }
    }

    nonisolated private static func analyze(url: URL, gain: Double, update: @escaping @Sendable (Double) -> Void) async -> [TargetSample] {
        let asset = AVURLAsset(url: url)
        guard let duration = try? await asset.load(.duration), duration.seconds.isFinite, duration.seconds > 0 else { return [] }
        let secs = min(duration.seconds, 600)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 800, height: 800)
        generator.requestedTimeToleranceBefore = CMTime(seconds: 0.08, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.08, preferredTimescale: 600)
        var points = [TargetSample]()
        var locked: CGPoint?
        let step = 0.25
        let total = Int(ceil(secs / step))
        for i in 0..<total {
            if Task.isCancelled { break }
            let t = Double(i) * step
            let requested = CMTime(seconds: t, preferredTimescale: 600)
            guard let frame = try? generator.copyCGImage(at: requested, actualTime: nil) else { continue }
            let request = VNDetectHumanRectanglesRequest()
            request.upperBodyOnly = false
            let handler = VNImageRequestHandler(cgImage: frame, options: [:])
            if (try? handler.perform([request])) != nil {
                let observations = request.results ?? []
                let closest = observations.max { lhs, rhs in
                    let a = CGPoint(x: lhs.boundingBox.midX, y: lhs.boundingBox.midY)
                    let b = CGPoint(x: rhs.boundingBox.midX, y: rhs.boundingBox.midY)
                    let ref = locked ?? CGPoint(x: 0.5, y: 0.5)
                    let da = hypot(a.x-ref.x, a.y-ref.y)
                    let db = hypot(b.x-ref.x, b.y-ref.y)
                    return da > db
                }
                if let chosen = closest {
                    let point = CGPoint(x: chosen.boundingBox.midX, y: chosen.boundingBox.midY)
                    let alpha = max(0.05, min(1, gain))
                    let smooth = CGPoint(
                        x: (locked?.x ?? point.x) * (1-alpha) + point.x * alpha,
                        y: (locked?.y ?? point.y) * (1-alpha) + point.y * alpha
                    )
                    locked = smooth
                    points.append(TargetSample(time: t, position: smooth, confidence: chosen.confidence))
                }
            }
            if i % 4 == 0 { update(Double(i+1)/Double(total)) }
        }
        return points
    }

    var activeSample: TargetSample? {
        guard !samples.isEmpty else { return nil }
        var left = 0, right = samples.count
        while left < right {
            let mid = (left + right) / 2
            if samples[mid].time < currentTime { left = mid + 1 } else { right = mid }
        }
        let index = min(left, samples.count-1)
        let prev = max(0, index-1)
        let candidate = abs(samples[index].time-currentTime) < abs(samples[prev].time-currentTime) ? samples[index] : samples[prev]
        return abs(candidate.time-currentTime) < 0.4 ? candidate : nil
    }
}

struct AimTrackView: View {
    @StateObject private var model = AimTrackModel()
    @State private var showingImporter = false

    var body: some View {
        GeometryReader { geo in
            ScrollView {
                VStack(spacing: 18) {
                    HStack(spacing: 10) {
                        Image(systemName: "scope").font(.system(size: 25, weight: .bold)).foregroundStyle(.cyan)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("AIMTRACK").font(.system(size: 23, weight: .black, design: .rounded))
                            Text("iOS TARGET DETECTION LAB").font(.system(size: 10, weight: .medium)).tracking(2).foregroundStyle(.cyan)
                        }
                        Spacer()
                    }
                    .padding(.top, 10)

                    ZStack {
                        RoundedRectangle(cornerRadius: 20).fill(Color(red: 0.02, green: 0.04, blue: 0.09))
                        if let player = model.player {
                            VideoPlayer(player: player)
                            if model.showTrack, let sample = model.activeSample {
                                GeometryReader { g in
                                    let point = CGPoint(x: sample.position.x * g.size.width, y: (1-sample.position.y) * g.size.height)
                                    ZStack {
                                        Circle().stroke(Color.cyan.opacity(0.35), lineWidth: 1).frame(width: 65, height: 65)
                                        Circle().stroke(.cyan, lineWidth: 2).frame(width: 27, height: 27)
                                        Rectangle().fill(.cyan).frame(width: 1, height: 48)
                                        Rectangle().fill(.cyan).frame(width: 48, height: 1)
                                    }
                                    .position(point)
                                    .allowsHitTesting(false)
                                }
                            }
                        } else {
                            VStack(spacing: 14) {
                                Image(systemName: "viewfinder").font(.system(size: 60)).foregroundStyle(.cyan.opacity(0.6))
                                Text("TARGET PREVIEW").font(.system(size: 12, weight: .semibold)).tracking(3).foregroundStyle(.gray)
                                Text("Open a gameplay recording").font(.subheadline).foregroundStyle(.gray)
                            }
                        }
                    }
                    .frame(height: min(geo.size.width * 0.64, 330))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.cyan.opacity(0.24), lineWidth: 1))

                    Button { showingImporter = true } label: {
                        Label("Import gameplay video", systemImage: "square.and.arrow.down")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .fontWeight(.bold)
                    }
                    .buttonStyle(.plain)
                    .background(Color.cyan, in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.black)

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: model.scanning ? "hourglass" : "dot.scope")
                                .foregroundStyle(.cyan)
                            Text(model.status).font(.subheadline).foregroundStyle(.white.opacity(0.8))
                        }
                        if model.scanning { ProgressView(value: model.progress).tint(.cyan) }
                        if let target = model.activeSample {
                            Text(String(format: "TARGET  X %.1f%% • Y %.1f%% • CONFIDENCE %.0f%%", target.position.x*100, target.position.y*100, Double(target.confidence)*100))
                                .font(.system(size: 10, design: .monospaced)).foregroundStyle(.cyan)
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16))

                    VStack(spacing: 17) {
                        Toggle("Show detected target", isOn: $model.showTrack).tint(.cyan)
                        VStack(alignment: .leading) {
                            HStack { Text("Target smoothing"); Spacer(); Text("\(Int(model.sensitivity*100))%").foregroundStyle(.cyan) }
                            Slider(value: $model.sensitivity, in: 0.05...1, step: 0.05).tint(.cyan)
                            Text("Applies to the next video analysis").font(.caption).foregroundStyle(.gray)
                        }
                    }
                    .padding(16)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16))
                    Text("Analyzes imported recordings locally with Apple Vision. Does not control or modify any other app.")
                        .font(.caption).foregroundStyle(.gray).multilineTextAlignment(.center)
                }
                .padding(16)
            }
        }
        .background(Color(red: 0.015, green: 0.025, blue: 0.06).ignoresSafeArea())
        .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.movie, .mpeg4Movie, .video]) { result in
            if case .success(let url) = result { model.importVideo(url) }
        }
    }
}
