#!/usr/bin/env bash
# Builds an UNSIGNED AimTrack.ipa with Xcode (macOS only).
# Usage: bash build_ipa.sh   ->  dist/AimTrack-unsigned.ipa
set -euo pipefail

cd "$(dirname "$0")"
ROOT="$PWD"
BUILD_DIR="$ROOT/build"
DIST_DIR="$ROOT/dist"

rm -rf "$BUILD_DIR" "$DIST_DIR"
mkdir -p "$DIST_DIR"

xcodebuild \
  -project AimTrack.xcodeproj \
  -target AimTrack \
  -configuration Release \
  -sdk iphoneos \
  SYMROOT="$BUILD_DIR" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build

APP="$BUILD_DIR/Release-iphoneos/AimTrack.app"
if [ ! -d "$APP" ]; then
  echo "Build finished but $APP was not found" >&2
  exit 1
fi

STAGE="$(mktemp -d)"
mkdir -p "$STAGE/Payload"
cp -R "$APP" "$STAGE/Payload/"
(cd "$STAGE" && zip -qry "$DIST_DIR/AimTrack-unsigned.ipa" Payload)
rm -rf "$STAGE"

echo "Done: $DIST_DIR/AimTrack-unsigned.ipa"
