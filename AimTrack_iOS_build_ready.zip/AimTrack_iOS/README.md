# AimTrack — iOS video target detection

An on-device visual tracking app for imported gameplay recordings. It uses Apple's Vision `VNDetectHumanRectanglesRequest` and shows a tracking reticle at the detected position during playback. The complete implementation is in `AimTrack/AimTrackApp.swift`.

**Not a CFL cheat:** this program is independent of CrossFire: Legends, cannot inject touches into that game, and does not bypass anti-cheat or prevent bans.

## Build an IPA on macOS

1. Open `AimTrack.xcodeproj` in Xcode 15 or later.
2. Select the AimTrack target > Signing & Capabilities, choose your developer team and a unique bundle identifier.
3. Connect your iPhone and choose Product > Archive.
4. Choose Distribute App and export an IPA with your signing account, if your signing method supports IPA export.

## Build an unsigned IPA without a Mac (GitHub Actions)

1. Create a new GitHub repository and upload everything in this folder (including `.github/workflows/build-ipa.yml`) to the repository root.
2. Open the **Actions** tab. The "Build unsigned IPA" workflow runs on every push (or press **Run workflow**).
3. When it finishes, download the `AimTrack-unsigned-ipa` artifact. It contains `AimTrack-unsigned.ipa`.
4. Install with a sideloading tool that signs the app with your Apple ID (Sideloadly, AltStore) or with TrollStore.

On a Mac you can produce the same file with `bash build_ipa.sh` (output: `dist/AimTrack-unsigned.ipa`).

## Features

- Import a saved video from Files.
- Analyze frames fully on-device using Apple's Vision human detector.
- Choose the nearest detection to the previous tracked point, retaining lock across successive sampled frames.
- Adjustable tracking smoothing and visual crosshair overlay.
- Playback of the analyzed video and a confidence readout.

No external services, network permissions, or API keys are required. iOS 16 or later.
